<?php get_header() ;?>


<?php echo do_shortcode('[rev_slider alias="home"][/rev_slider]'); ?>

